import {observable,action} from 'mobx-miniprogram'
export const store = observable({
    uid:"0c90e6e868154d44b6b3df9e90b24543",
    SubTopic:"0", // 订阅的话题
    PubTopic:{ // 用于发布消息的话题
        send2localPc:"1",
        send2esp32:"2"
    },
    eqList:[ // 在线的设备列表
    ],
    recordedList:[ //核酸检测记录

    ],
    total:1, // 核酸检测记录相关参数：服务器中一共有多少页核酸检测记录
    now:1, //核酸检测记录相关参数：当前是第几页
    updateRc:false, // 标志当前核酸检测记录已经更新
    setClient:action(function(newClient){ // 设置mqtt服务器客户端
        this.client = newClient
        console.log(newClient)
    }),
    getEqList:action(function(isReq){ // 别的页面用于获取在线设备列表
        if(isReq===true){
            console.log("请求online")
            this.client.publish(this.PubTopic.send2localPc,"online")
        }
        return this.eqList
    }),
    getRecordedList:action(function(){ // 别的页面用于获取核酸检测记录列表
        
          return this.recordedList
    }),
    updateEqList:action(function(newList){ 
        //更新在线设备列表
        // 时间。单位是毫秒
        var nowTime = Date.now()
        // 检查哪些设备是下线的，如果超过三分钟(也就是180000毫秒)没有收到信息就要删除这个设备
        for (let index = newList.length-1; index >= 0; index--) {
            const element = newList[index];
            if(nowTime - element.lastUpdate>180000){
                console.log("有设备过期了")
                newList.splice(index,1);
            } 
        }
        this.eqList = newList
    }),
    updateRcList:action(function(newList){ // 更新核酸检测记录列表
        this.recordedList = newList
    }),
    updateRcNum:action(function(total,now){
        this.total = total
        this.now = now
    }),
    getRcNum:action(function(){ 
        return {
            total:this.total,
            now:this.now
        }
    }),
    getUpdateRc:action(function(){ // 别的页面后去updateRc。判断现在核酸检测记录是否可以更新
        return this.updateRc
    }),
    setUpdateRc:action(function(newUpdateRc){ // 设置updateRc参数
        this.updateRc = newUpdateRc
    }),
})