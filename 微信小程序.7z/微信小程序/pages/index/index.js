import {createStoreBindings} from 'mobx-miniprogram-bindings'
import mqtt from "../../utils/js/mqtt.min.js"
import {store} from '../../store/store'
var timer = null
Page({

  /**
   * 页面的初始数据
   */
  data: {
    updating:false
  },
  readyInfo(){
    wx.navigateTo({
        url: "/pages/recordedInfo/recordedInfo",
      })
  },
  searchEquip(){
    wx.navigateTo({
        url: '/pages/equipmentList/equipmentList',
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.storeBindings = createStoreBindings(this,{
        store,
        fields:[
            "uid","SubTopic","PubTopic"
        ],
        actions:[
            "updateEqList","setClient","getEqList","getRecordedList","updateRcList","updateRcNum","getUpdateRc"
        ]
    })
    clearInterval(timer)
    timer = setInterval(() => {
        // 如果现在正在执行更新eqList的操作，就检查是否有哪些设备过期
        if(this.data.updating===true) return
        let eqList = this.getEqList()
        if(eqList.length===0) return 
        let oldEqList = JSON.parse(JSON.stringify(eqList))
        console.log(oldEqList)
        this.updateEqList(oldEqList)
    }, 5000);
  },
  mqttConnect(){
    var that = this
    //MQTT连接的配置
    var options= {
      keepalive: 60, //60s ，表示心跳间隔
      clean: true, //cleanSession不保持持久会话
      protocolVersion: 4, //MQTT v3.1.1
      clientId:this.data.uid
    }
    //初始化mqtt连接
     this.data.client = mqtt.connect('wxs://bemfa.com:9504/wss',options)
     this.setClient(this.data.client)
    
     // 连接mqtt服务器
     this.data.client.on('connect', function () {
      console.log('连接服务器成功')
      that.data.client.subscribe(that.data.SubTopic, function (err) {
        if (err) {
            console.log("订阅主题失败，错误信息为：",err)
        }
      })
    })
    //接收消息
    that.data.client.on('message', function (topic, message) {
        var msgObj = JSON.parse(message.toString())
        var newEq = true
        if(msgObj.mode=="online"){
            let eqObj = msgObj
            that.setData({
                updating:true
            })
            let nowTime = Date.now()
            let eqList = that.getEqList(false)
            let oldEqList = JSON.parse(JSON.stringify(eqList))
            // 找一下这个设备是否已经在在线设备列表里面
            for (let index = 0; index < oldEqList.length; index++) {
                const element = oldEqList[index];
                if(element.name===eqObj.name){
                    // 如果这个设备在列表里面，那就修改这个设备的最后更新时间
                    newEq = false
                    oldEqList[index].lastUpdate = nowTime
                    break
                }
            }
            if(newEq){
                //如果newEq是true表示这个设备是刚上线的设备
                oldEqList.push({
                    name:eqObj.name,
                    lastUpdate:nowTime
                })
            }
            
            that.updateEqList(oldEqList)
            that.setData({
                updating:false
            })
        }
        else if(msgObj.mode=="record"){
            let recordList = msgObj.list
            let total = msgObj.total
            let now = msgObj.now
            // 更新一下total和now
            that.updateRcNum(total,now)
            // 获取目前小程序中存储的核酸检测记录列表
            let oldRcList = JSON.parse(JSON.stringify(that.getRecordedList()))
            // 把获取的核酸检测记录跟目前的记录合并
            that.updateRcList(oldRcList.concat(recordList))
            // 设置updateRc为true。提醒recordedInfo页面可以更新核酸检测记录了
            this.setUpdateRc(true)
        }
        else if(msgObj.mode=="update"){
            let recordList = msgObj.list
            let total = msgObj.total
            let now = msgObj.now
            // 更新一下total和now
            that.updateRcNum(total,now)
            // 把获取的核酸检测记录设置为发送过来的核酸检测记录
            that.updateRcList(recordList)
            // 设置updateRc为true。提醒recordedInfo页面可以更新核酸检测记录了
            this.setUpdateRc(true)
        }
        // else if(msgObj.mode=="test"){

        // }



        // if(topic===that.data.SubTopic.getEq){
        //     that.setData({
        //         updating:true
        //     })
        //     let nowTime = Date.now()
        //     let eqList = that.getEqList()
        //     let oldEqList = JSON.parse(JSON.stringify(eqList))
        //     // 找一下这个设备是否已经在在线设备列表里面
        //     for (let index = 0; index < oldEqList.length; index++) {
        //         const element = oldEqList[index];
        //         if(element.name===msg){
        //             // 如果这个设备在列表里面，那就修改这个设备的最后更新时间
        //             newEq = false
        //             oldEqList[index].lastUpdate = nowTime
        //             break
        //         }
        //     }
        //     if(newEq){
        //         //如果newEq是true表示这个设备是刚上线的设备
        //         oldEqList.push({
        //             name:msg,
        //             lastUpdate:nowTime
        //         })
        //     }
            
        //     that.updateEqList(oldEqList)
        //     that.setData({
        //         updating:false
        //     })
        // }
        // else if(topic===that.data.SubTopic.getRc){
        //     //msg格式为{"name":"张三","number":"20203231037","result":"阴性","temperature":36.2}
        //     let recordedInfo = JSON.parse(msg)
        //     let date = new Date()
        //     recordedInfo.time = date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate()
        //     console.log(recordedInfo.time)
        //     let oldRecList = JSON.parse(JSON.stringify(that.getRecordedList()))
        //     oldRecList.push(recordedInfo)
        //     that.updateRcList(oldRecList)
        // }
    })

    //断线重连
    this.data.client.on("reconnect", function () {
      console.log("重新连接")
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.mqttConnect()
    // 请求获取已录信息
    this.data.client.publish(this.data.PubTopic.send2localPc,"get_record:1")
    // 查看当前在线的设备
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})