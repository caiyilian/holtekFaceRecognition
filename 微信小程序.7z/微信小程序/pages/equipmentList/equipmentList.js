// pages/equipment/equipmentList.js
import {createStoreBindings} from 'mobx-miniprogram-bindings'
import {store} from "../../store/store"
Page({

    /**
     * 页面的初始数据
     */
    data: {
        eqList:[
            //  {
            //         name:"001",
            //         lastUpdate:"2023-5-4"
            //     },
            //     {
            //         name:"002",
            //         lastUpdate:"2023-5-4"
            //     }
        ]
    },
    //刷新
    onRefresh(){
        //在当前页面显示导航条加载动画
        wx.showNavigationBarLoading(); 
        //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
        wx.showLoading({
            title: '刷新中...',
        })
        console.log("onRefresh")
        this.setData({
            eqList:this.formatEqList()
        })
        //隐藏loading 提示框
        wx.hideLoading();
        //隐藏导航条加载动画
        wx.hideNavigationBarLoading();
        //停止下拉刷新
        wx.stopPullDownRefresh();
    },
    
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.storeBindings = createStoreBindings(this,{
            store,
            fields:[
               
            ],
            actions:[
                "getEqList"
            ]
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        console.log("onShow")
        this.setData({
            eqList:this.formatEqList()
        })
    
        let date = new Date()
        console.log(date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate())
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },
    formatEqList(){
        //获取eqList并且格式化其中的lastUpdate时间为人类看得懂的时间而不是时间戳
        let eqList = this.getEqList(true)
        let List = JSON.parse(JSON.stringify(eqList))
        for (let index = 0; index < List.length; index++) {
            const element = List[index].lastUpdate;
            if(typeof(element)==="string") continue
            let newDate = new Date(element)
            let hh =  String(newDate.getHours()).padStart(2, '0');       //获取当前小时数(0-23)
            let mm = String(newDate.getMinutes()).padStart(2, '0');     //获取当前分钟数(0-59)
            let ss = String(newDate.getSeconds()).padStart(2, '0'); 
            List[index].lastUpdate = hh + ':' + mm + ':' + ss
        }
        return List
    },
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.onRefresh()
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})