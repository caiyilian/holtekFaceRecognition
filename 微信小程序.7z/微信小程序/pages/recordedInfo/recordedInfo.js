// pages/recordedInfo/recordedInfo.js
import {createStoreBindings} from 'mobx-miniprogram-bindings'
import {store} from "../../store/store"
Page({

    /**
     * 页面的初始数据
     */
    data: {
        coverHeight:0,
        timer:null,
        recordList:[],
        count:1,
        recordList1:[
            // {
            //     name:"刘懿逸",
            //     number:"20203231036",
            //     healthCode:"正常",
            //     temperature:36.6,
            //     time:"2023-5-4",
            //     result:"阴性"
            // },
            // {
            //     name:"李四",
            //     number:"20203231038",
            //     healthCode:"正常",
            //     temperature:36.3,
            //     time:"2023-5-4",
            //     result:"阴性"
            // },
            // {
            //     name:"王五",
            //     number:"20203231039",
            //     healthCode:"正常",
            //     temperature:36.4,
            //     time:"2023-5-4",
            //     result:"阴性"
            // },
            // {
            //     name:"赵六",
            //     number:"20203231040",
            //     healthCode:"正常",
            //     temperature:36.2,
            //     time:"2023-5-4",
            //     result:"阴性"
            // },
            // {
            //     name:"蔡依炼",
            //     number:"20203231037",
            //     healthCode:"正常",
            //     temperature:36.2,
            //     time:"2023-5-4",
            //     result:"阴性"
            // },
            
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.storeBindings = createStoreBindings(this,{
            store,
            fields:[
                "client","PubTopic"
            ],
            actions:[
                "updateRcList","setUpdateRc","getUpdateRc","getRcNum","getRecordedList"
            ]
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        this.setData({
            recordList:this.getRecordedList()
        })
        var that = this
        wx.request({
            url: 'http://localhost:8000/getRecord', //接口地址
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
                  // 返回值
                  that.updateRcList(res.data)
                  that.setData({
                    recordList:res.data
                })
            },
            fail(res){
                console.log("失败了")
            }
          })

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },
 //刷新
 onRefresh(){
     console.log("下拉刷新")
    // //在当前页面显示导航条加载动画
    // wx.showNavigationBarLoading(); 
    // //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
    // wx.showLoading({
    //     title: '刷新中...',
    // })
   
    var that = this
            //在当前页面显示导航条加载动画
            wx.showNavigationBarLoading(); 
            //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
            wx.showLoading({
                title: '刷新中...',
            })
        wx.request({
            url: 'http://localhost:8000/getRecord', //接口地址
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
                  // 返回值
                  that.updateRcList(res.data)
                  that.setData({
                    recordList:res.data
                })
                      //隐藏loading 提示框
                    wx.hideLoading();
                    //隐藏导航条加载动画
                    wx.hideNavigationBarLoading();
                    //停止下拉刷新
                    wx.stopPullDownRefresh();
            },
            fail(res){
                console.log("失败了")
                wx.hideLoading();
                //隐藏导航条加载动画
                wx.hideNavigationBarLoading();
                //停止下拉刷新
                wx.stopPullDownRefresh();
            }
          })
    // //隐藏loading 提示框
    // wx.hideLoading();
    // //隐藏导航条加载动画
    // wx.hideNavigationBarLoading();
    // //停止下拉刷新
    // wx.stopPullDownRefresh();
},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.onRefresh()
    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
        // console.log("上拉触底")
        // let Obj = this.getRcNum()
        // if(Obj.total===Obj.now) return
        // // 先发个消息让本地服务器把核酸检测记录发送过来
        // this.data.client.publish(this.data.PubTopic.send2localPc,"get_record:"+String(Number(Obj.now+1)))
        // // 开启遮挡，防止在加载的时候用户去滑动页面
        // this.setData({
        //     coverHeight:this.data.recordList.length*360
        // })
        //     //在当前页面显示导航条加载动画
        // wx.showNavigationBarLoading(); 
        // //显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
        // wx.showLoading({
        //     title: '刷新中...',
        // })
        // this.setData({
        //     timer:setInterval(() => {
        //         if(this.getUpdateRc()===true){
        //             // 如果本地服务器发送核酸检测记录的话。这个updateRc就是true
        //             // 我们把updateRc设置成false同时关闭计时器
        //             clearInterval(this.data.timer)
        //             this.setUpdateRc(false)
        //             // 更新这个页面的核酸检测记录
        //             this.setData({
        //                 recordList:this.getRecordedList()
        //             })
        //             //隐藏loading 提示框
        //             wx.hideLoading();
        //             //隐藏导航条加载动画
        //             wx.hideNavigationBarLoading();
        //             // 关掉遮挡
        //             this.setData({
        //                 coverHeight:0
        //             })
        //         }
                
        //     }, 1000)
        // })

    
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },
    fun(){

    }
})